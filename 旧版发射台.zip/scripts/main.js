Events.on(ClientLoadEvent, e => {
    Blocks.launchPad.buildVisibility = BuildVisibility.shown;
    Vars.content.getByName(ContentType.block, "launch-pad").alwaysUnlocked = true;
});